using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class OxygenSystem : MonoBehaviour
{
    [Header("UI Settings")]
    public TextMeshProUGUI oxygenText;
    [Header("Death UI")]
    public GameObject deathScreenPanel;

    [Header("Oxygen Settings")]
    public float maxOxygen = 100f;
    public float currentOxygen;
    public float drainRate = 0f; // How much oxygen you lose per second

    private bool isDead = false;

    void Start()
    {
        Time.timeScale = 1f; 
        // Start with a full tank
        maxOxygen = PlayerStats.GetMaxOxygen();
        currentOxygen = maxOxygen;
    }

    void Update()
    {
        if (isDead) return;

        // Drain the oxygen based on the engine weight!
        currentOxygen -= (drainRate + PlayerStats.GetOxygenDrainRate()) * Time.deltaTime;

        if (oxygenText != null)
        {
            oxygenText.text = "Oxygen: " + Mathf.CeilToInt(currentOxygen).ToString();
        }

        if (currentOxygen <= 0)
        {
            currentOxygen = 0;
            isDead = true;
            MissionFailed();
        }
    }

    private void MissionFailed()
    {
        Debug.Log("Nebula Trails: mission failed, oxygen ran out.");
        Time.timeScale = 1f;
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        SceneManager.LoadScene("AstraFailure");
    }
    public void ReturnToSpaceCenter()
    {
        Time.timeScale = 1f; // Unpause before leaving
        SceneManager.LoadScene("AstraMoonSelection");
    }
}