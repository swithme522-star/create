using UnityEngine;
using UnityEngine.SceneManagement;

public class MoonDestination : MonoBehaviour
{
    [Header("Moon Settings")]
    public string sceneName; 
    
    [Tooltip("0 = Phobos, 1 = Io/Europa, 2 = Callisto/Titan")]
    public int requiredEngineLevel = 0;

    [Header("UI References")]
    public GameObject errorText; 

    public void TryToFly()
    {
        if (errorText != null) errorText.SetActive(false);

        // Check if the player's engine level is high enough
        if (PlayerStats.engineLevel >= requiredEngineLevel)
        {
            int moonIndex = sceneName == "Phobos" ? 0 : sceneName == "Europa" ? 1 : sceneName == "Titan" ? 2 : -1;
            if (moonIndex >= 0)
            {
                const string keyPrefix = "ASTRA_3_MOONS_V2_";
                if (moonIndex > PlayerPrefs.GetInt(keyPrefix + "Unlocked", 0))
                {
                    if (errorText != null) errorText.SetActive(true);
                    Debug.Log("Moon is locked. Complete the previous mission first.");
                    return;
                }
                PlayerPrefs.SetInt(keyPrefix + "Selected", moonIndex);
                PlayerPrefs.Save();
            }
            NebulaCinematics.PlayTravel(sceneName);
        }
        else
        {
            if (errorText != null) errorText.SetActive(true);
            Debug.Log("Need Engine Level " + requiredEngineLevel + " to fly here!");
        }
    }
}