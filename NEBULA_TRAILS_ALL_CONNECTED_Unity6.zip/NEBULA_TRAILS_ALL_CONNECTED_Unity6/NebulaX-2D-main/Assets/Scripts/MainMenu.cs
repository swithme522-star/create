using System;
using AudioScripts;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Audio;
using UnityEngine.UI;


public class MainMenu : MonoBehaviour
{
    public AudioMixer audioMixer;
    public Slider SfxVolumeSlider;
    public Slider MusicVolumeSlider;
    private void Start()
    {
        LoadVolume();
    }

    
    public void Play()
    {
        NebulaCinematics.PlayIntro("AstraMoonSelection");
    }

    public void Quit()
    {
        Debug.Log("Quitting Game");
        Application.Quit();
    }

    public void UpdateMusicVolume(float volume)
    {
        audioMixer.SetFloat("MusicVolume", volume);
    }

    public void UpdateSoundVolume(float volume)
    {
        audioMixer.SetFloat("SFXVolume", volume);
    }

    public void SaveVolume()
    {
        audioMixer.GetFloat("MusicVolume", out float musicVolume);
        PlayerPrefs.SetFloat("MusicVolume", musicVolume);
        
        audioMixer.GetFloat("SFXVolume", out float sfxVolume);
        PlayerPrefs.SetFloat("SFXVolume", sfxVolume);
    }

    public void LoadVolume()
    {
        if (MusicVolumeSlider != null) MusicVolumeSlider.value = PlayerPrefs.GetFloat("MusicVolume");
        if (SfxVolumeSlider != null) SfxVolumeSlider.value = PlayerPrefs.GetFloat("SFXVolume");
    }
    
    
}
