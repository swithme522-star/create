#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

// Guarantees that pressing the Unity toolbar Play button starts at the title menu.
// Also exposes two simple Tools menu actions for the team.
[InitializeOnLoad]
public static class NebulaTrailsPlayFromStart
{
    private const string MenuPath = "Assets/AstraExpansion/Scenes/AstraMainMenu.unity";

    static NebulaTrailsPlayFromStart()
    {
        EditorApplication.delayCall += Configure;
    }

    private static void Configure()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling)
            return;
        SceneAsset menu = AssetDatabase.LoadAssetAtPath<SceneAsset>(MenuPath);
        if (menu == null)
        {
            Debug.LogWarning("Nebula Trails: main menu missing at " + MenuPath);
            return;
        }
        EditorSceneManager.playModeStartScene = menu;
        // The common cause of the blue screen was an empty Unsaved/Untitled Scene.
        // Only replace it if it has no saved path AND no GameObjects.
        Scene active = SceneManager.GetActiveScene();
        if (active.IsValid() && string.IsNullOrEmpty(active.path) && active.rootCount == 0)
            EditorSceneManager.OpenScene(MenuPath, OpenSceneMode.Single);
    }

    [MenuItem("Tools/Nebula Trails/1 - Open Main Menu")]
    private static void OpenMenu()
    {
        if (EditorApplication.isPlaying)
        {
            Debug.Log("Stop Play Mode before opening another scene in the Editor.");
            return;
        }
        if (EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
            EditorSceneManager.OpenScene(MenuPath, OpenSceneMode.Single);
        Configure();
    }

    [MenuItem("Tools/Nebula Trails/2 - Play Full Game From Start")]
    private static void PlayGame()
    {
        Configure();
        if (!EditorApplication.isPlaying)
            EditorApplication.isPlaying = true;
    }

    [MenuItem("Tools/Nebula Trails/3 - Test Currently Open Scene")]
    private static void TestCurrentScene()
    {
        EditorSceneManager.playModeStartScene = null;
        Debug.Log("Nebula Trails: next Play will test your currently open scene. After recompiling the project the main-menu start is restored.");
    }
}
#endif
