using System;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Video;
using UnityEngine.UI;

public sealed class NebulaCinematics : MonoBehaviour
{
    private VideoPlayer player;
    private RenderTexture texture;
    private GameObject canvasRoot;
    private string destination;
    private bool advancing;
    private float startedAt;
    private bool preparing;

    public static void PlayIntro(string nextScene) => Play("Opening_Original", nextScene);
    public static void PlayTravel(string nextScene) => Play("RocketTravel_Original", nextScene);

    private static void Play(string clipName, string nextScene)
    {
        if (string.IsNullOrEmpty(nextScene)) return;
        if (FindFirstObjectByType<NebulaCinematics>() != null) return;
        var clip = Resources.Load<VideoClip>("NebulaMovies/" + clipName);
        if (clip == null)
        {
            Debug.LogWarning("Nebula Trails: video not imported yet: " + clipName);
            SceneManager.LoadScene(nextScene);
            return;
        }
        Time.timeScale = 1f;
        GameObject go = new GameObject("Nebula Trails Full-Screen Cinematic");
        DontDestroyOnLoad(go);
        NebulaCinematics cinematic = go.AddComponent<NebulaCinematics>();
        cinematic.StartVideo(clip, nextScene);
    }

    private void StartVideo(VideoClip clip, string nextScene)
    {
        destination = nextScene;
        startedAt = Time.realtimeSinceStartup;
        preparing = true;
        // The video is one single original file. It is NOT split into separate slides/screens.
        canvasRoot = new GameObject("Full Screen Video Overlay", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler));
        canvasRoot.transform.SetParent(transform, false);
        Canvas canvas = canvasRoot.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.overrideSorting = true;
        canvas.sortingOrder = 32000;
        CanvasScaler scaler = canvasRoot.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        var view = new GameObject("Video image - full viewport", typeof(RectTransform), typeof(RawImage));
        view.transform.SetParent(canvasRoot.transform, false);
        RectTransform rect = view.GetComponent<RectTransform>();
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
        RawImage image = view.GetComponent<RawImage>();
        image.color = Color.white;
        texture = new RenderTexture(Mathf.Max(640, Screen.width), Mathf.Max(360, Screen.height), 0, RenderTextureFormat.ARGB32);
        texture.Create();
        image.texture = texture;
        player = gameObject.AddComponent<VideoPlayer>();
        player.playOnAwake = false;
        player.isLooping = false;
        player.skipOnDrop = false;
        player.source = VideoSource.VideoClip;
        player.clip = clip;
        player.renderMode = VideoRenderMode.RenderTexture;
        player.targetTexture = texture;
        player.aspectRatio = VideoAspectRatio.Stretch;
        player.audioOutputMode = VideoAudioOutputMode.Direct;
        player.loopPointReached += OnVideoFinished;
        player.errorReceived += OnVideoError;
        player.prepareCompleted += OnPrepared;
        player.Prepare();
        // No Skip or Continue button. Playback ends on its own.
    }
    private void OnPrepared(VideoPlayer source)
    {
        preparing = false;
        startedAt = Time.realtimeSinceStartup;
        source.Play();
    }
    private void Update()
    {
        if (advancing) return;
        if (player == null) { Finish(); return; }
        float elapsed = Time.realtimeSinceStartup - startedAt;
        if (preparing && elapsed > 15f) { Debug.LogWarning("Video prepare timed out"); Finish(); }
        else if (!preparing && player.clip != null && elapsed > (float)player.clip.length + 7f)
        { Debug.LogWarning("Video finished without completion event"); Finish(); }
    }
    private void OnVideoFinished(VideoPlayer _) { Finish(); }
    private void OnVideoError(VideoPlayer _, string message) { Debug.LogWarning("Nebula video: " + message); Finish(); }
    private void Finish()
    {
        if (advancing) return;
        advancing = true;
        string to = destination;
        if (player != null) { player.Stop(); player.targetTexture = null; }
        if (texture != null) { texture.Release(); Destroy(texture); }
        Destroy(gameObject);
        SceneManager.LoadScene(to);
    }
}
