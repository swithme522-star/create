using UnityEngine;
using UnityEngine.SceneManagement;

// Additive collectible, preserving all original player, inventory and mining scripts.
[DisallowMultipleComponent]
public class NebulaDiscoverable : MonoBehaviour
{
    public enum FindKind { Astronaut, RocketPart }
    public FindKind kind;
    public string uniqueId;
    public bool saveCollection = true;
    private bool pickedUp;

    private string SaveKey { get { return "NebulaFound_" + uniqueId; } }

    private void Awake()
    {
        if (saveCollection && !string.IsNullOrEmpty(uniqueId) && PlayerPrefs.GetInt(SaveKey, 0) == 1)
            Destroy(gameObject);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (pickedUp) return;
        bool isPlayer = other.CompareTag("Player") || other.transform.root.CompareTag("Player");
        if (!isPlayer) return;
        pickedUp = true;
        if (saveCollection && !string.IsNullOrEmpty(uniqueId))
            PlayerPrefs.SetInt(SaveKey, 1);
        PlayerPrefs.Save();
        Debug.Log("Nebula Trails found: " + kind + " / " + uniqueId);
        string moon = SceneManager.GetActiveScene().name;
        Destroy(gameObject);
        CheckMoonComplete(moon);
    }

    private static void CheckMoonComplete(string moon)
    {
        int index, astronauts, partsStart, partsEnd;
        switch (moon)
        {
            case "Phobos": index = 0; astronauts = 2; partsStart = 1; partsEnd = 2; break;
            case "Europa": index = 1; astronauts = 3; partsStart = 3; partsEnd = 4; break;
            case "Titan": index = 2; astronauts = 3; partsStart = 5; partsEnd = 7; break;
            default: return;
        }
        string completeKey = "NebulaLevelCompleted_" + moon;
        if (PlayerPrefs.GetInt(completeKey, 0) == 1) return;
        for (int i = 1; i <= astronauts; i++)
            if (PlayerPrefs.GetInt("NebulaFound_" + moon + "_Astronaut_" + i, 0) == 0) return;
        for (int i = partsStart; i <= partsEnd; i++)
            if (PlayerPrefs.GetInt("NebulaFound_" + moon + "_RocketPart_" + i, 0) == 0) return;

        const string prefix = "ASTRA_3_MOONS_V2_";
        PlayerPrefs.SetInt(completeKey, 1);
        PlayerPrefs.SetInt(prefix + "Selected", index);
        PlayerPrefs.SetInt(prefix + "Unlocked", Mathf.Max(PlayerPrefs.GetInt(prefix + "Unlocked", 0), Mathf.Min(2, index + 1)));
        PlayerPrefs.SetInt(prefix + "LastReward", 180);
        PlayerPrefs.SetInt(prefix + "Credits", PlayerPrefs.GetInt(prefix + "Credits", 450) + 180);
        PlayerPrefs.SetInt(prefix + "Crystals", PlayerPrefs.GetInt(prefix + "Crystals", 2) + 1);
        PlayerPrefs.Save();
        Time.timeScale = 1f;
        Debug.Log("Nebula Trails mission complete: " + moon);
        SceneManager.LoadScene("AstraSuccess");
    }
}
