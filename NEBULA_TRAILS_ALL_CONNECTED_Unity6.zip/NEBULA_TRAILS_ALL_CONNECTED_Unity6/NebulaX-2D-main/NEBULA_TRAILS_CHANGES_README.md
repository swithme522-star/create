# NEBULA TRAILS — added to YOUR uploaded NebulaX-2D project

This is an edited copy of the original uploaded Unity project, not a replacement UI prototype.
Existing scenes, player, tilemaps, scripts, and economy were preserved wherever possible.

## Install
1. Extract this ZIP to a new folder (don't overwrite your team's original project).
2. Unity Hub > Add > Add project from disk; select the extracted `NebulaX-2D-main` folder (contains Assets, Packages, ProjectSettings).
3. Let Unity import the assets, open `Assets/AstraExpansion/Scenes/AstraMainMenu.unity` (active first Build scene) or `Assets/Scenes/Menu.unity` (original secondary menu).
4. Press Play: Play button -> opening video (14 seconds, full-screen, uncut) -> SpaceCenter. Select a moon via SpaceCenter -> rocket animation (5 seconds, full-screen, uncut) -> actual Phobos / Europa / Titan level. Videos have NO skip or continue buttons.
5. For any already-open editor window, close Play Mode first. Test after project import finishes.

## Level additions (editable in the Hierarchy)
Open `Assets/Scenes/Phobos.unity`, `Europa.unity`, or `Titan.unity`. Expand the root named `Nebula Additions - [Moon] (editable)`.
The original scenes were not replaced, and no existing rocks, player scripts, or tilemaps were deleted.

- Phobos: 2 missing astronaut sprites, 2 rocket fragments, spread-out separate rocks.
- Europa: 3 missing astronauts, 2 rocket fragments, separate rocks, transparent decals derived from the supplied cracked Europa ground texture. Existing floor tiles remain untouched.
- Titan: 3 missing astronauts, 3 rocket fragments, separate rocks.
- The 8 astronauts are four distinct poses repeated as needed, since the supplied sprite sheet contains four little astronaut poses (not eight separate character models).
- Astronauts and rocket pieces are trigger collectibles. On entering them as a Player, they disappear and their collected status saves through PlayerPrefs. The pre-existing player inventory system was not changed to accommodate them.
- Rock objects are individual decorative sprites, not new mineable Harvestable prefabs; pre-existing mining logic and harvesting objects remain unchanged.
- Each object has its own Transform. Move the objects manually in the Scene view if their starting coordinates conflict with obstacles in your existing levels.

## Full-screen video
Both of the MP4 videos supplied by the team are included unmodified as continuous clips under `Assets/NebulaAdditions/Resources/NebulaMovies/`.
The game view fills the entire screen using a full-screen overlay; no split/slideshow, Skip, or Continue control is added.
If the project runs at a non-16:9 resolution, the image can be stretched to fill. At 16:9 it preserves the source proportions.

## Files changed / added
- Modified only these existing scripts: `Assets/Scripts/MainMenu.cs`, `Assets/Scripts/MoonDestination.cs`, and the demo travel call in `Assets/AstraExpansion/Scripts/AstraGameFlow.cs`.
- Added `Assets/NebulaAdditions/` with split sprites, scripts, and supplied videos.
- Added new isolated GameObjects to the three ORIGINAL level scenes.
- All other original assets remain as in the uploaded ZIP.

## Testing limitation
File syntax, expected scene files, and ZIP integrity were checked outside Unity. Unity Editor itself is not available here, so the actual visuals, trigger collisions, and video playback still require a Unity test. Existing team project scripts may have unrelated errors.
