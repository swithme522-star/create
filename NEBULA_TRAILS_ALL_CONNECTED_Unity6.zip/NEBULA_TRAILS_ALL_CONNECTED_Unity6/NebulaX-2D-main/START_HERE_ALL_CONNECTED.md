# NEBULA TRAILS — ALL CONNECTED (Unity 6)

## Open the project — فتح المشروع
1. CLOSE Unity and Unity Hub project sessions from older Nebula versions.
2. Extract this ZIP to a **new folder**. Do not paste its files over any older project.
3. Unity Hub > Projects > Add > Add project from disk. Pick the INSIDE `NebulaX-2D-main` folder containing `Assets`, `Packages`, `ProjectSettings`.
4. Once imports and compiles finish, PRESS THE LARGE PLAY TRIANGLE IN UNITY. The project now has an Editor startup script that starts from `AstraMainMenu` EVEN if you had an empty Untitled scene open.
5. Alternatively, top menu: Tools > Nebula Trails > **1 - Open Main Menu**, then press Play; or **2 - Play Full Game From Start**.
6. Open the **Game** tab to see the interface, not the Scene perspective view.

## What opens automatically — التسلسل
Unity toolbar Play -> Nebula Trails MAIN MENU -> click PLAY MISSION -> full-screen complete opening movie (no Skip, no Continue) -> PHOBOS/EUROPA/TITAN Moon Selection -> choose unlocked moon -> full-screen complete rocket movie (no Skip, no Continue) -> original REAL 2D moon level -> collect missing astronauts + rocket pieces -> Success -> Next Moon unlock, or oxygen depleted -> Fail -> Retry/Shop/Moon Selection.

At main menu, HOW TO PLAY displays an overlay. From Moon Selection, Shop/Resources and Main Menu buttons work. Shop purchases now update the original `PlayerStats`' engine/oxygen fields as well.

## Assets preserved
- 3 original playable moon scenes, original player movement, original mining/inventory, original art and videos.
- 8 crew across the 3 moons: Phobos 2 / Europa 3 / Titan 3.
- 7 rocket fragments: Phobos 2 / Europa 2 / Titan 3.
- Separate rocks, including Europa texture; no crowded spritesheet used as a single object.
- Individual moon scenery and scene pickups under "Nebula Additions" in each moon.
- Old background-music manager scripts removed (SFX preserved).

## Important notes
- The **first Play** in the Unity EDITOR always starts at the title scene thanks to `Assets/Editor/NebulaTrailsPlayFromStart.cs` and Unity's `EditorSceneManager.playModeStartScene`.
- If you specifically need to test a moon scene by itself: Tools > Nebula Trails > 3 - Test Currently Open Scene, then Play. On next script reload start-at-menu returns.
- Save the new version using File > Save Project. Keep the old team files as backups.
- Unity Editor is NOT installed in this environment; these are source edits with structural checks, not a verified Unity run. If you see red Console messages, send the FIRST complete red error.
- Unity's yellow warning about deprecated Input Manager is unrelated to the blue/empty screen.

## قائمة المراحل
PLAY -> فيديو الشخصية -> اختيار القمر -> فيديو الصاروخ -> مرحلة اللعب -> النجاح/الخسارة -> فتح التالي، تلقائيًا وبدون فتح المشاهد يدويًا.
